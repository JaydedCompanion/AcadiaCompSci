//*************************************************************************************************
//
// 	Tree.java				Author: Juan Sebastian Callejas Rodriguez		ID:100143996
//
//	This program prints out a tree outline using asterisks
//
// *************************************************************************************************

public class Tree {

	public static void Tree () {

		System.out.println ("             -					");
		System.out.println ("           _/ \\_				");
		System.out.println ("          \\     /				");
		System.out.println ("          /_'O'_\\				");
		System.out.println ("           _O_'_				");
		System.out.println ("          _'_'O'_				");
		System.out.println (" Happy   O'_O_'_O_  Holidays	");
		System.out.println ("        _'_O_'_'_O_			");
		System.out.println ("       _O_'_O_'_O_'_			");
		System.out.println ("          [_____]				");
		System.out.println ("           \\___/				");

	}

}
